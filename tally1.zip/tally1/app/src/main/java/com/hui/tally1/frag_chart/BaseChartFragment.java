package com.hui.tally1.frag_chart;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.hui.tally1.R;
import com.hui.tally1.adapter.ChartItemAdapter;
import com.hui.tally1.db.ChartItemBean;
import com.hui.tally1.db.DBManager;

import java.util.ArrayList;
import java.util.List;

/**
 * 图表基类Fragment，提供公共图表功能
 */
public abstract class BaseChartFragment extends Fragment {
    protected static final int DEFAULT_OFFSET = 20;

    protected ListView chartLv;
    protected int year;
    protected int month;
    protected List<ChartItemBean> mDatas;
    protected ChartItemAdapter itemAdapter;
    protected BarChart barChart;
    protected TextView chartTv;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_incom_chart, container, false);
        initView(view);
        initData();
        return view;
    }

    protected void initView(View view) {
        chartLv = view.findViewById(R.id.frag_chart_lv);
    }

    protected void initData() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            year = bundle.getInt("year");
            month = bundle.getInt("month");
        }

        mDatas = new ArrayList<>();
        itemAdapter = new ChartItemAdapter(getContext(), mDatas);
        chartLv.setAdapter(itemAdapter);
        addLVHeaderView();
    }

    protected void addLVHeaderView() {
        View headerView = getLayoutInflater().inflate(R.layout.item_chartfrag_top, null);
        chartLv.addHeaderView(headerView);

        barChart = headerView.findViewById(R.id.item_chartfrag_chart);
        chartTv = headerView.findViewById(R.id.item_chartfrag_top_tv);

        configureChartAppearance();
        setAxis(year, month);
        setAxisData(year, month);
    }

    protected void configureChartAppearance() {
        barChart.getDescription().setEnabled(false);
        barChart.setExtraOffsets(DEFAULT_OFFSET, DEFAULT_OFFSET, DEFAULT_OFFSET, DEFAULT_OFFSET);
    }

    protected abstract void setAxisData(int year, int month);

    protected void setAxis(int year, int month) {
        configureXAxis(month);
        setYAxis(year, month);
    }

    private void configureXAxis(int month) {
        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(true);
        xAxis.setLabelCount(31);
        xAxis.setTextSize(12f);
        xAxis.setValueFormatter(new DayOfMonthValueFormatter(month));
        xAxis.setYOffset(10);
    }

    protected abstract void setYAxis(int year, int month);

    public void setDate(int year, int month) {
        this.year = year;
        this.month = month;
        refreshChart();
    }

    protected void refreshChart() {
        barChart.clear();
        barChart.invalidate();
        setAxis(year, month);
        setAxisData(year, month);
    }

    public void loadData(int year, int month, int kind) {
        List<ChartItemBean> list = DBManager.getChartListFromAccounttb(year, month, kind);
        mDatas.clear();
        mDatas.addAll(list);
        itemAdapter.notifyDataSetChanged();
    }

    /**
     * 自定义X轴标签格式化器
     */
    private static class DayOfMonthValueFormatter extends ValueFormatter {
        private final int month;

        DayOfMonthValueFormatter(int month) {
            this.month = month;
        }

        @Override
        public String getFormattedValue(float value) {
            int day = (int) value;
            if (day == 0) return month + "-1";
            if (day == 14) return month + "-15";

            if (month == 2) {
                if (day == 27) return month + "-28";
            } else if (is31DaysMonth(month)) {
                if (day == 30) return month + "-31";
            } else {
                if (day == 29) return month + "-30";
            }
            return "";
        }

        private boolean is31DaysMonth(int month) {
            return month == 1 || month == 3 || month == 5 || month == 7
                    || month == 8 || month == 10 || month == 12;
        }
    }
}