package com.hui.tally1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.hui.tally1.adapter.AccountAdapter;
import com.hui.tally1.db.AccountBean;
import com.hui.tally1.db.DBManager;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {
    ListView searchLv;
    EditText searchEt;
    TextView emptyTv;
    List<AccountBean>mDatas;   //数据源
    AccountAdapter adapter;    //适配器对象
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        initView();
        mDatas = new ArrayList<>();
        adapter = new AccountAdapter(this,mDatas);
        searchLv.setAdapter(adapter);
        searchLv.setEmptyView(emptyTv);   //设置无数局时，显示的控件
    }

    private void initView() {
        searchEt = findViewById(R.id.search_et);
        searchLv = findViewById(R.id.search_lv);
        emptyTv = findViewById(R.id.search_tv_empty);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.search_iv_back) {
            // 点击返回按钮
            finish();
        } else if (id == R.id.search_iv_sh) {
            // 执行搜索操作
            performSearch();
        }
    }

    private void performSearch() {
        // 获取搜索关键词（自动去除首尾空格）
        String searchQuery = searchEt.getText().toString().trim();

        // 空输入检查
        if (TextUtils.isEmpty(searchQuery)) {
            showEmptySearchWarning();
            return;
        }

        // 执行数据库搜索
        executeSearch(searchQuery);
    }

    // 显示空输入警告
    private void showEmptySearchWarning() {
        Toast.makeText(this, R.string.search_empty_warning, Toast.LENGTH_SHORT).show();
    }

    // 执行搜索逻辑
    private void executeSearch(String query) {
        // 从数据库获取搜索结果
        List<AccountBean> searchResults = DBManager.getAccountListByRemarkFromAccounttb(query);

        // 更新UI显示
        updateSearchResults(searchResults);
    }

    // 更新搜索结果列表
    private void updateSearchResults(List<AccountBean> results) {
        mDatas.clear();          // 清空旧数据
        mDatas.addAll(results);  // 添加新数据
        adapter.notifyDataSetChanged(); // 刷新列表
    }
}
