# tally
记账本Android安卓应用

![0546459523868668A7FF8F041A41186E](https://user-images.githubusercontent.com/72775628/160228780-57a7c289-c4af-4d0c-9057-1fb2dad3da1d.jpg)

---
![202D5EDF45F204EDABC472C1D732FFF3](https://user-images.githubusercontent.com/72775628/160228788-e0ea41e5-e3fe-4461-abe7-333aa80c00cc.jpg)

---
![8DD8F100967C4EFA792C653EE5416CF3](https://user-images.githubusercontent.com/72775628/160228794-5a7ea65e-a06c-47ff-b5d0-5dbd7c40d17b.jpg)

---
![BEDB0F75344A2157E30795EBE2C5861C](https://user-images.githubusercontent.com/72775628/160228799-10bb813d-8c4d-4d85-ae66-d3511e09ddb2.jpg)

---
